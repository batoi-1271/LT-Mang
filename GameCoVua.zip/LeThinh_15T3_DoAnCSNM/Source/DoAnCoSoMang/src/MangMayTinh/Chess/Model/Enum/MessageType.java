/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MangMayTinh.Chess.Model.Enum;

/**
 *
 * @author thinhle
 */
public enum MessageType {
    string, bool, move, message, result, startGame, turn, isFirstPlayer, name, surrender, endGame;
}
